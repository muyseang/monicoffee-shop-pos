from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether,
)

OUT = "/Users/poma/Desktop/IT_STEP_FINAL PROJECT/Android_kotlin/output/pdf/Moni_Coffee_Shop_POS_Week_1_Progress_Report.pdf"
BLUE = colors.HexColor("#173F5F")
TEAL = colors.HexColor("#20639B")
LIGHT_BLUE = colors.HexColor("#EAF2F8")
AMBER = colors.HexColor("#FFF3CD")
GREY = colors.HexColor("#5B6770")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="TitleCustom", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=20, leading=24, textColor=BLUE, alignment=TA_CENTER, spaceAfter=8))
styles.add(ParagraphStyle(name="SubTitle", parent=styles["Normal"], fontName="Helvetica", fontSize=9.5, leading=13, textColor=GREY, alignment=TA_CENTER, spaceAfter=14))
styles.add(ParagraphStyle(name="H1Custom", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=13, leading=16, textColor=BLUE, spaceBefore=12, spaceAfter=6))
styles.add(ParagraphStyle(name="BodyCustom", parent=styles["BodyText"], fontName="Helvetica", fontSize=9.2, leading=13, spaceAfter=5))
styles.add(ParagraphStyle(name="Small", parent=styles["BodyText"], fontName="Helvetica", fontSize=8.2, leading=10.5))
styles.add(ParagraphStyle(name="TableHead", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=8, leading=9.5, textColor=colors.white))
styles.add(ParagraphStyle(name="TableCell", parent=styles["BodyText"], fontName="Helvetica", fontSize=7.8, leading=9.7))

def P(text, style="BodyCustom"):
    return Paragraph(text, styles[style])

def link(label, url):
    return f'<link href="{url}" color="#1B5E9A"><u>{label}</u></link>'

def table(rows, widths, header=True):
    result = Table(rows, colWidths=widths, repeatRows=1 if header else 0, hAlign="LEFT")
    commands = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#C7D4DF")),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    if header:
        commands += [("BACKGROUND", (0, 0), (-1, 0), BLUE), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white)]
    for i in range(1 if header else 0, len(rows)):
        if i % 2 == 0:
            commands.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F7FAFC")))
    result.setStyle(TableStyle(commands))
    return result

def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#C7D4DF"))
    canvas.line(doc.leftMargin, 1.25*cm, A4[0]-doc.rightMargin, 1.25*cm)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(GREY)
    canvas.drawString(doc.leftMargin, 0.8*cm, "Moni Coffee Shop POS & Client Ordering - Week 1 Progress Report")
    canvas.drawRightString(A4[0]-doc.rightMargin, 0.8*cm, f"Page {doc.page}")
    canvas.restoreState()

story = []
story += [
    P("WEEK 1 PROGRESS REPORT", "TitleCustom"),
    P("Moni Coffee Shop POS & Client Ordering", "SubTitle"),
]

summary = table([
    [P("Project status", "TableHead"), P("Yellow", "TableHead"), P("Mentor", "TableHead"), P("Mr. Chau Magn", "TableHead")],
    [P("Programme", "TableCell"), P("Graduation Project - FT SD E17", "TableCell"), P("Reporting period", "TableCell"), P("Week 1", "TableCell")],
    [P("Team", "TableCell"), P("Ung Muy Seang; Sang Visal", "TableCell"), P("Trello board", "TableCell"), P(link("02 Coffee Shop POS", "https://trello.com/b/VhMQZHpy/02-coffee-shop-pos"), "TableCell")],
], [2.2*cm, 5.1*cm, 2.6*cm, 5.4*cm])
story += [summary, Spacer(1, 10)]

story += [P("1. Executive summary", "H1Custom")]
story += [P("Week 1 established the project direction, technical ownership, initial use cases, proposal revision, and shared repository setup. The project is Yellow: five planning/setup cards are ready for mentor review, the Week 1 report is still in progress, and no card has been formally moved to Completed. There is no recorded technical blocker, but final evidence and mentor decisions are required before the next development phase.")]

story += [P("2. Current Trello status", "H1Custom")]
story += [P("Live Trello review at report preparation: <b>0</b> cards in Completed, <b>1</b> card in In Progress, <b>5</b> cards in Ready for Mentor Review, and <b>0</b> cards in Blocked.")]
ready_rows = [[P("Deliverable", "TableHead"), P("Current status", "TableHead"), P("Card link", "TableHead")]]
for name, url in [
    ("Assign Team Responsibilities", "https://trello.com/c/Z8SCY5Zy/1-planning-assign-team-responsibilities"),
    ("Confirm MVP Scope", "https://trello.com/c/ntYOla5s/3-planning-confirm-mvp-scope"),
    ("Create Initial Use Cases", "https://trello.com/c/EdiL1IlV/5-design-create-initial-use-cases"),
    ("Revise Project Proposal", "https://trello.com/c/XFNgKn2Q/2-documentation-revise-project-proposal"),
    ("Create and Configure GitHub Repository", "https://trello.com/c/tcyqZBpc/4-repository-create-and-configure-github-repository"),
]:
    ready_rows.append([P(name, "TableCell"), P("Ready for Mentor Review", "TableCell"), P(link("Open card", url), "TableCell")])
story += [table(ready_rows, [5.7*cm, 4.0*cm, 4.8*cm]), Spacer(1, 6)]
story += [P("Completed-card links: None at the time of review. The five cards above are evidence of work awaiting mentor review; they are not reported as formally completed.", "Small")]

story += [P("3. Incomplete work and reasons", "H1Custom")]
incomplete = [
    [P("Work item", "TableHead"), P("State", "TableHead"), P("Reason / remaining work", "TableHead")],
    [P(link("Submit Week 1 Report", "https://trello.com/c/FM48WpDF/6-documentation-submit-week-1-report"), "TableCell"), P("In Progress", "TableCell"), P("Attach the final report PDF and a screen-recording link; then submit for mentor review.", "TableCell")],
    [P("Formal card completion", "TableCell"), P("Pending", "TableCell"), P("The five preparation cards require mentor review and checklist verification before moving to Completed.", "TableCell")],
    [P("Screen recording", "TableCell"), P("Not linked", "TableCell"), P("A short recording demonstrating the Trello board, repository, and current setup has not yet been supplied.", "TableCell")],
]
story += [table(incomplete, [4.6*cm, 2.6*cm, 7.3*cm])]

story += [PageBreak(), P("4. Current blockers and risks", "H1Custom")]
story += [P("<b>Technical blocker:</b> None recorded in Trello.")]
blockers = [
    "Confirm the student recorded as official Team Lead for report ownership.",
    "Attach the final screen-recording link as evidence.",
    "Complete mentor review of the five Ready for Mentor Review cards.",
    "Preserve the Mandatory MVP scope until any change is agreed in writing.",
]
for b in blockers:
    story.append(P(f"- {b}"))

story += [P("5. Contribution of each member", "H1Custom")]
contrib = [
    [P("Member", "TableHead"), P("Role", "TableHead"), P("Week 1 contribution", "TableHead")],
    [P("Ung Muy Seang", "TableCell"), P("Backend & Admin Dashboard Lead", "TableCell"), P("Defined ownership for Django REST API, authentication and roles, menu/category/inventory backend, order/POS logic, and the Django admin dashboard. Contributed to planning, repository setup, integration testing, report/documentation, and presentation preparation.", "TableCell")],
    [P("Sang Visal", "TableCell"), P("Mobile & Client Integration Lead", "TableCell"), P("Defined ownership for the Android Kotlin application, API integration, menu browsing, cart, checkout, order tracking, and mobile UI/UX. Contributed to planning, integration testing, report/documentation, and presentation preparation.", "TableCell")],
]
story += [table(contrib, [3.2*cm, 4.1*cm, 7.2*cm])]

story += [P("6. Next-week cards", "H1Custom")]
next_rows = [[P("Planned work", "TableHead"), P("Owner", "TableHead"), P("Trello evidence", "TableHead")]]
for name, owner, url in [
    ("Create Custom User Model and Roles", "Ung Muy Seang", "https://trello.com/c/w9dU8Th6/7-backend-create-custom-user-model-and-roles"),
    ("Implement Authentication APIs", "Ung Muy Seang", "https://trello.com/c/89deefPz/8-backend-implement-authentication-apis"),
    ("Design Menu and Order Models", "Ung Muy Seang", "https://trello.com/c/EvfvB70r/9-database-design-menu-and-order-models"),
    ("Implement Menu Browsing", "Sang Visal", "https://trello.com/c/kvpW5nI1/12-mobile-implement-menu-browsing"),
    ("Implement Shopping Cart", "Sang Visal", "https://trello.com/c/Hjq6ucsy/11-mobile-implement-shopping-cart"),
]:
    next_rows.append([P(name, "TableCell"), P(owner, "TableCell"), P(link("Open card", url), "TableCell")])
story += [table(next_rows, [6.4*cm, 3.6*cm, 4.5*cm])]

story += [P("7. Questions requiring mentor decisions", "H1Custom")]
questions = [
    "Please approve or request changes to the Mandatory MVP scope.",
    "Please confirm the technical role division: Ung Muy Seang as Backend & Admin Dashboard Lead and Sang Visal as Mobile & Client Integration Lead.",
    "Please confirm which student should be recorded as the official Team Lead.",
    "May USD/KHR dual-currency payment remain optional until the core ordering flow is reliable?",
    "Is the current Mandatory MVP appropriate for the 12-week timeline, or should any feature be reduced before implementation begins?",
]
for i, q in enumerate(questions, 1):
    story.append(P(f"{i}. {q}"))

story += [P("8. Evidence and project boundary", "H1Custom")]
story += [P(f"Repository: {link('monicoffee-shop-pos', 'https://github.com/muyseang/monicoffee-shop-pos.git')}<br/>Planning/report evidence: {link('Google Drive file', 'https://drive.google.com/file/d/1wsoSfMBhftUpA6C_EVPOLpnQkAMh20Pf/view?usp=sharing')}<br/>Screen recording: <b>Pending - link must be added before submission.</b>")]
story += [P("The Mandatory MVP uses Django/Django REST Framework with MySQL 8, a Django template-based admin dashboard, and an Android Native Kotlin client. It records cash or manually confirmed QR payments only; it does not connect to a real payment gateway, process real bank details, or claim real-time status updates. Order status uses manual refresh or polling; real-time push is future work.")]

doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=1.7*cm, rightMargin=1.7*cm, topMargin=1.45*cm, bottomMargin=1.7*cm, title="Moni Coffee Shop POS - Week 1 Progress Report", author="Ung Muy Seang and Sang Visal")
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print(OUT)
